function Section (name){
	var self = this;

	self.name = "/" + name;
}

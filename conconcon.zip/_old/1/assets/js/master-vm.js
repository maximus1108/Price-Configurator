function MasterViewModel(){
	var self = this;
	
	self.sections = ko.observableArray([
		new Section("standard features")	,
		new Section("structure & functionality")		
	]);
}

ko.applyBindings(new MasterViewModel());
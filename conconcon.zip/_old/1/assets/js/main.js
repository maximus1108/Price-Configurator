requirejs.config({
	knockout: "core/js/vendor/knockout",
	jquery: "core/js/vendor/jquery"	,
	section: "",
	subsection "",
});

requirejs(
	["jquery", "knockout"],
	function($, ko){
		
		function MasterViewModel(){
			
			var self = this;
			
			self.components = ko.observableArray();
			
			self.sections = ko.observableArray([
				new Section("standard features"),
				new Section("structure & functionality")		
			]);
		}
		
		ko.applyBindings(new MasterViewModel());		
	}
);

